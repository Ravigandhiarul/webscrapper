from djongo import models
from django import forms

class Address(models.Model):
    street = models.CharField(max_length=200)
    city = models.CharField(max_length=200)
    province = models.CharField(max_length=200)
    postalcode = models.IntegerField()
    country = models.CharField(max_length=200)

    class Meta:
        abstract = True


class AddressForm(forms.ModelForm):
    class Meta:
        model = Address
        fields = "__all__"


class Contact(models.Model):
    firstname = models.CharField(max_length=200)
    lastname = models.CharField(max_length=200)
    title = models.CharField(max_length=200)
    phone = models.CharField(max_length=200)

    class Meta:
        abstract = True


class ContactForm(forms.ModelForm):
    class Meta:
        model = Contact
        fields = "__all__"


class Company(models.Model):
    name = models.CharField(max_length=100)
    address = models.ArrayField(
        model_container=Address,
        model_form_class=AddressForm
    )
    contact = models.ArrayField(
        model_container=Contact,
        model_form_class=ContactForm
    )
    description = models.TextField()
    datasource = models.TextField()