import csv

from django.shortcuts import render, redirect

from company.extract import extract_from_page



def getDataFrom(csvfilename):
    csv_fp = open(f'company.csv', 'r')
    reader = csv.DictReader(csv_fp)
    headers = [col for col in reader.fieldnames]
    out = [row for row in reader]
    return (headers, out)


def show(request):
    extract_from_page()
    headers, out = getDataFrom('company.csv')
    new_headers, new_out = getDataFrom('new_manual.csv')
    return render(request, "show.html", {'headers': headers, 'data': out, "new_headers": new_headers, "new_out": new_out})
