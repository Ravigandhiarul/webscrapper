# importing the libraries
from bs4 import BeautifulSoup
import requests
import csv

def extract_from_page():
    # Step 1: Sending a HTTP request to a URL
    url = "https://www.yellowpages.ca/search/si/1/food/Toronto+ON"
    html_content = requests.get(url).text
    soup = BeautifulSoup(html_content, "html.parser")
    names = []
    captions = []
    descriptions = []
    opens = []
    addresses = []
    regions = []
    postalcodes = []
    company_table = soup.findAll(class_='listing__name--link')
    for name in company_table:
        try:
            names.append(name.text)
        except:
            pass

    address = soup.findAll('span', attrs={'itemprop': 'addressLocality'})
    for i in address:
        try:
            addresses.append(i.text)
        except:
            pass
    codes = soup.findAll('span', attrs={'itemprop': 'postalCode'})
    for i in codes:
        try:
            postalcodes.append(i.text)
        except:
            pass

    region = soup.findAll('span', attrs={'itemprop': 'addressRegion'})
    for i in region:
        try:
            regions.append(i.text)
        except:
            pass

    c = soup.findAll(class_='listing__captext')
    for i in c:
        try:
            captions.append(i.text)
        except:
            pass

    status = soup.findAll('a', attrs={'class': 'merchant__status-text'})
    for i in status:
        try:
            opens.append(i.text)
        except:
            pass

    description = soup.findAll(class_='listing__details__teaser')
    for i in description:
        try:
            descriptions.append(i.text)
        except:
            pass

    with open(f"company.csv", 'w', newline='') as out_file:
        headers = [
            "names", "captions", "is_open", "address", "postalcodes", "regions", "descriptions"
        ]  # == t_headers
        writer = csv.writer(out_file, lineterminator='\n')
        writer.writerow(headers)
        for i in range(len(names)):
            try:
                desc = descriptions[i].replace("See more text", "").replace("more...", "").strip()
                writer.writerow([names[i], captions[i], opens[i], addresses[i], postalcodes[i], regions[i], desc])
            except:
                pass
